/**
 * Created by aveto on 30/3/18.
 */
function square(x) {
    return x * x;
}

var f = square;

console.log(square);
console.log(f);